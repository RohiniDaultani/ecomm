<h2 align="center">Repository for Hacktoberfest 2022 from GDSC NSEC (Web Team)</h2>


<p align="center">
<img src="https://user-images.githubusercontent.com/38348296/194700380-35dbaaf9-7610-4b61-8806-bdb6e22dea6a.jpg" width="40%">
</p>


Welcome Everyone! This is a beginner friendly Ecommerce project for the folks who are newbies in open source and want to participate in Hacktoberfest 2022. Hope you'll get to learn a lot of things and sharpen your skills. Happy Coding:)

## Tech Stack
- HTML
- CSS
- JavaScript

## How To Contribute
- Firstly, fork this repository[https://github.com/dscnsec/ecommerce-frontend/fork].
- Then `git clone` your forked repo in your localhost.
- After that, make valid changes and commit it in your forked repo.
- Now open a pull request from your forked repo to merge the changes in our main repo.
